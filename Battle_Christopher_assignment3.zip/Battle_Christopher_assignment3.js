/* "There is a jumpshot in team "
 Author: Christopher L. Battle
 SDI 1310 Project 3 
 */
 

 
 alert("Welcome to the journey of a man \, who fell in love with the jumpshot!");
 
 // Variables
 var myName = "Christopher";
 var myGyms = ["Welsch Fitness", "Globo Gym", "Average Joes"];
 var winningScore = 21;
 var teamNames = ["Nets", "Swish"];
 var myTeam = "Nets"
 
 
 
  //Intro
 
 console.log("I need to pick my players for this pickup game" + " my opponent has aleready picked his two players");
 
 
 //Conditionals
 

 

  
 
 
 
 
