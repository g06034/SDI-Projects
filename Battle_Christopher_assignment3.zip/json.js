/* 
 Author: Christopher L. Battle
 SDI 1310 Project 3
 JSON  
 */

var json = {
    "prospects": [
        {
            "name": "David",
            "age": 23,
            "jumpshot": 9,
            "teamWorthy": true
        },
        {
            "name": "Allan",
            "age": 24,
            "jumpshot": 7,
            "teamworthy": true
        },
        {
            "name": "Gerald",
            "age": 25,
            "skill": 3,
            "teamworthy": false
        }
    ]
};